<!-- HTML -->
<template>
<div>
    <h1>Index</h1>
    <div a>{{info}}</div>
</div>
</template>

<!-- Vue -->

<script>
import {
    getInfo
} from '@/api/demo'
export default {
    data() {
        return {
            info: '',
        };
    },
    created() {
        this.getinfo()
    },
    methods: {
      getinfo() {
          getInfo().then(response => {
              console.log(response);
              this.info = response;
          }).catch(e => {
              console.log(e);
          });
       },
    },
};
</script>

<!-- CSS样式 -->

<style scoped>
</style>
